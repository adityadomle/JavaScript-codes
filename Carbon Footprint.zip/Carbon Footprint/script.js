document.querySelector('.get-started').addEventListener('click', function() {
    alert('Welcome to Carbon Footprint! Let’s get started on reducing your impact!');
});